const db = require('../config/db');

class DonationModel {
  static async createDonation({ name, email, phone, disaster_id, amount }) {
    return db.tx(async t => {
      // 1. Find or create Donor record
      let donor = await t.oneOrNone('SELECT donor_id FROM Donor WHERE email = $1', [email]);
      if (!donor) {
        donor = await t.one(
          'INSERT INTO Donor(name, email, phone) VALUES($1, $2, $3) RETURNING donor_id',
          [name, email, phone]
        );
      }

      // 2. Insert Donation record
      const donation = await t.one(
        'INSERT INTO Donation(donor_id, disaster_id, amount) VALUES($1, $2, $3) RETURNING *',
        [donor.donor_id, disaster_id, amount]
      );

      return donation;
    });
  }

  static async getByDisaster(disasterId) {
    const query = `
      SELECT dn.donation_id, dn.amount, dn.donation_date, d.name AS donor_name
      FROM Donation dn
      JOIN Donor d ON dn.donor_id = d.donor_id
      WHERE dn.disaster_id = $1
      ORDER BY dn.donation_date DESC
    `;
    return await db.any(query, [disasterId]);
  }
}

module.exports = DonationModel;