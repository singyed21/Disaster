const db = require('../config/db');

class AllocationModel {
  static async createAllocation(disasterId, organisationId, amount) {
    const query = `
      INSERT INTO FundAllocation(disaster_id, organisation_id, amount)
      VALUES($1, $2, $3) RETURNING *
    `;
    return await db.one(query, [disasterId, organisationId, amount]);
  }

  static async getAllocationSummary() {
    const query = `
      SELECT 
        fa.allocation_id,
        d.title AS disaster_title,
        ro.name AS organisation_name,
        fa.amount,
        fa.allocation_date
      FROM FundAllocation fa
      JOIN Disaster d ON fa.disaster_id = d.disaster_id
      JOIN ReliefOrganization ro ON fa.organisation_id = ro.organisation_id
      ORDER BY fa.allocation_date DESC
    `;
    return await db.any(query);
  }
}

module.exports = AllocationModel;