const db = require('../config/db');

class DisasterModel {
  static async getAllActive() {
    const query = `
      SELECT 
        d.*, 
        COALESCE(SUM(dn.amount), 0) AS amount_raised
      FROM Disaster d
      LEFT JOIN Donation dn ON d.disaster_id = dn.disaster_id
      WHERE d.status = 'Active'
      GROUP BY d.disaster_id
    `;
    return await db.any(query);
  }

  static async getById(disasterId) {
    const query = `
      SELECT 
        d.*, 
        COALESCE(SUM(dn.amount), 0) AS amount_raised
      FROM Disaster d
      LEFT JOIN Donation dn ON d.disaster_id = dn.disaster_id
      WHERE d.disaster_id = $1
      GROUP BY d.disaster_id
    `;
    return await db.oneOrNone(query, [disasterId]);
  }
}

module.exports = DisasterModel;