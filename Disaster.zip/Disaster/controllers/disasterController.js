const DisasterModel = require('../models/disasterModel');

exports.getActiveDisasters = async (req, res) => {
  try {
    const disasters = await DisasterModel.getAllActive();
    res.render('index', { disasters });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.getDisasterDetails = async (req, res) => {
  try {
    const disaster = await DisasterModel.getById(req.params.id);
    if (!disaster) {
      return res.status(404).render('404', { message: 'Disaster campaign not found' });
    }
    res.render('campaign', { disaster });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};