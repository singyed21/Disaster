const AllocationModel = require('../models/allocationModel');

exports.recordAllocation = async (req, res) => {
  const { disaster_id, organisation_id, amount } = req.body;

  if (!disaster_id || !organisation_id || !amount || amount <= 0) {
    return res.status(400).json({ error: 'Invalid allocation inputs.' });
  }

  try {
    await AllocationModel.createAllocation(disaster_id, organisation_id, amount);
    res.redirect('/allocations/summary');
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.getAllocationSummary = async (req, res) => {
  try {
    const allocations = await AllocationModel.getAllocationSummary();
    res.render('allocation-summary', { allocations });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};