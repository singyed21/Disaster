const DonationModel = require('../models/donationModel');

exports.processDonation = async (req, res) => {
  const { name, email, phone, disaster_id, amount } = req.body;

  // Application flow validation step
  if (!name || !email || !disaster_id || !amount || amount <= 0) {
    return res.status(400).json({ error: 'Please provide valid donation details.' });
  }

  try {
    const donation = await DonationModel.createDonation({ name, email, phone, disaster_id, amount });
    
    // Redirect or render confirmation View
    res.render('confirmation', { donation, message: 'Thank you for your donation!' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};