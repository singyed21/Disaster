const express = require('express');
const router = express.Router();
const disasterController = require('../controllers/disasterController');

router.get('/', disasterController.getActiveDisasters);
router.get('/disasters/:id', disasterController.getDisasterDetails);

module.exports = router;