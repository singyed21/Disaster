const express = require('express');
const router = express.Router();
const allocationController = require('../controllers/allocationController');

router.post('/allocations/record', allocationController.recordAllocation);
router.get('/allocations/summary', allocationController.getAllocationSummary);

module.exports = router;